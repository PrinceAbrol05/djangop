from django.apps import AppConfig


class ApporConfig(AppConfig):
    name = 'appor'
