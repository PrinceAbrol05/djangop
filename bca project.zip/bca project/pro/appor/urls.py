from django.urls import path,include
from django.contrib import admin
from . import views 


urlpatterns = [
    path('login', views.login,name='login'),
    path('', views.index,name='index'),#landing page 
    path('about/', views.about,name='about'),
    path('cart/',views.cart,name="cart"),
    path('contact/',views.contact,name="contact"),
]