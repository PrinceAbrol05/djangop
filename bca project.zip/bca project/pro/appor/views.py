from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.shortcuts import render
from .models import product
from math import ceil

import mysql.connector as c
from django.http import HttpResponseRedirect


# Create your views here.

def index(request):
        products = product. objects. all()
        print(products)
        n=len(products)
        nslides = n//4 + ceil ((n/4)-(n//4))
        params ={"no_of_sileds":nslides, range:(nslides),'product':products}
        #return HttpResponse('test page')
        return render_to_response("appor/index.html",params)



def login(request):
    email=''
    pwd =''
    if request.method=='GET':
        email = request.GET['email']
        pwd = request.GET['password'] 
        #db connection
        

        con = c.connect(host='localhost',user='root',password='root',database='log')
       
        cur = con.cursor()
        cur.execute("select * from users where email='"+email+"' and pwd='"+pwd+"'")

        # o = cur.fetchall()

        if email !='' and pwd !='':
                #return HttpResponse("https://www.w3schools.com")
                return render_to_response("appor/index.html")
             
        else:
                return HttpResponse('login fail')



def about(request):
        return render_to_response("appor/about.html")

        
def cart(request):
        return render_to_response("appor/cart.html")

def contact(request):
        if request.method=="post":
                print(request)
                name= request.POST.get('name','')
                email= request.POST.get('email' ,'')
                phone= request.POST.get('phone' ,'')
                desc= request.POST.get('desc' ,'')
                print(name)
                print(email)
                print(phone)
                print(desc)
        return render(request,"appor/contact.html")